import { Component } from '@angular/core';

@Component({
  selector: 'app-add-follower',
  templateUrl: './add-follower.component.html',
  styleUrls: ['./add-follower.component.css']
})
export class AddFollowerComponent {

}
