import { Component } from '@angular/core';

@Component({
  selector: 'app-previous-cases',
  templateUrl: './previous-cases.component.html',
  styleUrls: ['./previous-cases.component.css']
})
export class PreviousCasesComponent {

}
