import { Component } from '@angular/core';

@Component({
  selector: 'app-create-skill-request',
  templateUrl: './create-skill-request.component.html',
  styleUrls: ['./create-skill-request.component.css']
})
export class CreateSkillRequestComponent {

}
