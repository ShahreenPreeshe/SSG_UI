import { Component } from '@angular/core';

@Component({
  selector: 'app-chargeable-event',
  templateUrl: './chargeable-event.component.html',
  styleUrls: ['./chargeable-event.component.css']
})
export class ChargeableEventComponent {

}
