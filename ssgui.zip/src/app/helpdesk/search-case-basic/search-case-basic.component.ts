import { Component } from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {MatButtonModule} from '@angular/material/button';

@Component({
  selector: 'app-search-case-basic',
  templateUrl: './search-case-basic.component.html',
  styleUrls: ['./search-case-basic.component.css']
})
export class SearchCaseBasicComponent{
  
}