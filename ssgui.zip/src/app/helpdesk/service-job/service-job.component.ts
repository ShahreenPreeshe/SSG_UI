import { Component } from '@angular/core';

@Component({
  selector: 'app-service-job',
  templateUrl: './service-job.component.html',
  styleUrls: ['./service-job.component.css']
})
export class ServiceJobComponent {

}
