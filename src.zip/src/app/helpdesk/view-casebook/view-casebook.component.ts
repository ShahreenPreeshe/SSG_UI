import { Component } from '@angular/core';

@Component({
  selector: 'app-view-casebook',
  templateUrl: './view-casebook.component.html',
  styleUrls: ['./view-casebook.component.css']
})
export class ViewCasebookComponent {

}
