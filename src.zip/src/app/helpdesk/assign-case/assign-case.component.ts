import { Component } from '@angular/core';

@Component({
  selector: 'app-assign-case',
  templateUrl: './assign-case.component.html',
  styleUrls: ['./assign-case.component.css']
})
export class AssignCaseComponent {

}
