import { Component } from '@angular/core';

@Component({
  selector: 'app-sub-service-cases',
  templateUrl: './sub-service-cases.component.html',
  styleUrls: ['./sub-service-cases.component.css']
})
export class SubServiceCasesComponent {

}
