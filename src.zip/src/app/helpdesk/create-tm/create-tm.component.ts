import { Component } from '@angular/core';

@Component({
  selector: 'app-create-tm',
  templateUrl: './create-tm.component.html',
  styleUrls: ['./create-tm.component.css']
})
export class CreateTmComponent {

}
