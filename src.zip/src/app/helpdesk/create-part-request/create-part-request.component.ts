import { Component } from '@angular/core';

@Component({
  selector: 'app-create-part-request',
  templateUrl: './create-part-request.component.html',
  styleUrls: ['./create-part-request.component.css']
})
export class CreatePartRequestComponent {

}
