import { Component } from '@angular/core';

@Component({
  selector: 'app-casebook',
  templateUrl: './casebook.component.html',
  styleUrls: ['./casebook.component.css']
})
export class CasebookComponent {

}
