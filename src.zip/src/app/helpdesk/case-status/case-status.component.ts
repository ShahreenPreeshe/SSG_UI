import { Component } from '@angular/core';

@Component({
  selector: 'app-case-status',
  templateUrl: './case-status.component.html',
  styleUrls: ['./case-status.component.css']
})
export class CaseStatusComponent {

}
