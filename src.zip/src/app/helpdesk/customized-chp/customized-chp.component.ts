import { Component } from '@angular/core';

@Component({
  selector: 'app-customized-chp',
  templateUrl: './customized-chp.component.html',
  styleUrls: ['./customized-chp.component.css']
})
export class CustomizedChpComponent {

}
